#! /usr/bin/python
__author__ = 'guy'


class Bike():
    def __init__(self, sensors):
        self.sensors = sensors
